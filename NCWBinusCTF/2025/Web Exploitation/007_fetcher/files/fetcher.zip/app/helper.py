from urllib.parse import urlparse, unquote

def is_valid_url(url):
    banned_protocols = ['file', 'gopher']
    
    url_parts = urlparse(url)
    if url_parts.scheme in banned_protocols:
        return False
    
    if not url_parts.netloc.startswith('xjirada.net'):
        return False
    
    blacklisted_chars = ["\"","'"]
    if any(char in url_parts.path for char in blacklisted_chars):
        return False
    
    if any(char in unquote(url_parts.path) for char in blacklisted_chars):
        return False
    
    return True