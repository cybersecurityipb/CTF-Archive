from flask import Flask, request, render_template, session, url_for, redirect
from hashlib import md5
import pycurl
import yaml
import json
from io import BytesIO

import redis
import os

from sigma import *
from helper import *

app = Flask(__name__)
app.secret_key = os.urandom(24).hex()
redis_host = os.getenv("REDIS_HOST", "redis")
redis_port = int(os.getenv("REDIS_PORT", "6379"))

r = redis.Redis(host=redis_host, port=redis_port, decode_responses=True)

@app.route('/')
def index():
    if not session.get('username'):
        return redirect(url_for('login'))
    return render_template('index.html', username=session['username'], role=session['role'], post_instagram_tersigma=post_instagram_tersigma)

@app.route('/admin', methods=['GET','POST'])
def admin():
    if session.get('role') != 'admin':
        return "Access denied.", 403
    
    if request.method == 'GET':
        return render_template('admin.html')
    
    key = request.form.get('key','')
    
    data = r.get(f'yaml:{key}')
    if not data:
        return "YAML not found in cache. <meta http-equiv=\"refresh\" content=\"1; url=/admin\">", 400
    
    yaml.load(data, Loader=yaml.Loader)
    
    return "YAML processed. <meta http-equiv=\"refresh\" content=\"1; url=/admin\">", 200

@app.route('/post', methods=['GET','POST'])
def post():
    if not session.get('username'):
        return redirect(url_for('login'))
    
    if request.method == 'GET':
        
        keys = r.keys('post:*')
        posts = {key: json.loads(r.get(key)) for key in keys}
        
        return render_template('post.html', posts=posts)
    
    title, content = request.form.get('title',''), request.form.get('content','')
    
    if not title or not content:
        return "Title and content are required.", 400
    
    if r.get(f'post:{session["username"]}:{title}'):
        return "You have already created a post with this title. <meta http-equiv=\"refresh\" content=\"1; url=/post\">", 400
    
    r.set(f'post:{session["username"]}:{title}', json.dumps({'author': session['username'], 'title': title, 'content': content}), ex=300)
    
    return redirect(url_for('post'))

@app.route('/user')
def profile():
    if request.remote_addr != '127.0.0.1':
        return "Access denied.", 403
    
    accounts = r.keys(f'account:*')
    users = []
    for acc in accounts:
        data = json.loads(r.get(acc))
        data.pop('salt', None)
        users.append(data)
    return json.dumps(users)

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'GET':
        return render_template('register.html')
    
    username = request.form.get('username')
    password = request.form.get('password')
    salt = os.urandom(3).hex()
    
    user = r.setnx(f'account:{username}', json.dumps({'username': username, 'password_hash': md5((salt + password).encode()).hexdigest(), 'role': 'user', 'salt': salt}))
    
    if not user:
        return "Username already exists.", 400
    
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'GET':
        return render_template('login.html')
    
    username = request.form.get('username')
    password = request.form.get('password')
    
    user = r.get(f'account:{username}')
    if not user:
        return "Invalid username or password.", 400
    
    user_data = json.loads(user)
    if user_data['password_hash'] != md5((user_data['salt'] + password).encode()).hexdigest():
        return "Invalid username or password.", 400
    
    session['username'] = user_data['username']
    session['role'] = user_data['role']
    return redirect(url_for('index'))

@app.route('/fetch', methods=['GET','POST'])
def fetch():
    if not session.get('username'):
        return redirect(url_for('login'))
    
    if request.method == 'GET':
        return render_template('fetch.html')
    
    url = request.form.get('url','')
    
    if not is_valid_url(url):
        return "Invalid URL.", 400
    
    cache = r.get(f'cache:{url}')
    if cache:
        return (cache, 200, {'Content-Type': 'text/html'})
    try:
        r.set(f'cache:{url}', 'processing..', ex=300) 
        buffer = BytesIO()
        c = pycurl.Curl()
        c.setopt(c.URL, url)
        c.setopt(c.WRITEDATA, buffer)
        c.setopt(c.TIMEOUT, 5)
        c.perform()
        c.close()
        content = buffer.getvalue().decode('utf-8')
        r.set(f'cache:{url}', content, ex=300)
        return (content, 200, {'Content-Type': 'text/html'})
    except Exception as e:
        r.delete(f'cache:{url}')
        return (str(e), 500)
    
@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)