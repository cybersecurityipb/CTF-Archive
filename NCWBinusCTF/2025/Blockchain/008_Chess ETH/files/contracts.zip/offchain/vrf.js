const { ethers } = require("ethers");

const WS_RPC_URL = process.env.WS_RPC_URL || "ws://127.0.0.1:8545";
const HTTP_RPC_URL = process.env.HTTP_RPC_URL || "http://127.0.0.1:8545";
const ORACLE_PRIVATE_KEY = process.env.ORACLE_PRIVATE_KEY;
const VRF_COORDINATOR_ADDRESS = process.env.VRF_COORDINATOR_ADDRESS;
const GAS_PADDING = 50_000;

const VRF_COORDINATOR_ABI = [
  "event RandomWordsRequested(" +
    "bytes32 indexed keyHash," +
    "uint256 requestId," +
    "uint256 preSeed," +
    "uint64 indexed subId," +
    "uint16 minimumRequestConfirmations," +
    "uint32 callbackGasLimit," +
    "uint32 numWords," +
    "address indexed sender" +
    ")",
  "function fulfillRandomWordsWithOverride(" +
    "uint256 _requestId," +
    "address _consumer," +
    "uint256[] _words" +
    ") external",
];

async function main() {
  const wsProvider = new ethers.WebSocketProvider(WS_RPC_URL);
  const httpProvider = new ethers.JsonRpcProvider(HTTP_RPC_URL);
  const wallet = new ethers.Wallet(ORACLE_PRIVATE_KEY, httpProvider);
  const coordinator = new ethers.Contract(
    VRF_COORDINATOR_ADDRESS,
    VRF_COORDINATOR_ABI,
    wallet
  );
  const iface = new ethers.Interface(VRF_COORDINATOR_ABI);
  const event = iface.getEvent("RandomWordsRequested");
  const eventTopic = event.topicHash ?? event.topic;

  const filter = {
    topics: [eventTopic],
    address: VRF_COORDINATOR_ADDRESS,
  };

  console.log("[oracle] listening...");
  console.log("[oracle] wallet address:", await wallet.getAddress());

  wsProvider.on(filter, async (log) => {
    let parsed;
    try {
      parsed = iface.parseLog(log);
    } catch (err) {
      console.error("[oracle] failed to parse log:", err);
      return;
    }

    const { requestId, preSeed, callbackGasLimit, numWords, sender } =
      parsed.args;

    const words = [];
    for (let i = 0; i < Number(numWords); i++) {
      const wi = ethers.keccak256(
        ethers.solidityPacked(["uint256", "uint256"], [preSeed, BigInt(i)])
      );
      words.push(ethers.toBigInt(wi));
    }

    try {
      const gasLimit =
        Number(callbackGasLimit) > 0
          ? Number(callbackGasLimit) + GAS_PADDING
          : 300_000;
      const tx = await coordinator.fulfillRandomWordsWithOverride(
        requestId,
        sender,
        words,
        { gasLimit }
      );
      const receipt = await tx.wait();
      console.log("[oracle] fulfill tx mined in block:", receipt.blockNumber);
    } catch (err) {
      console.error("[oracle] error while fulfilling:", err);
    }
  });

  wsProvider.on("error", (err) => {
    console.error("[oracle] websocket error:", err);
  });
}

main().catch((err) => {
  console.error("fatal error in oracle:", err);
});
