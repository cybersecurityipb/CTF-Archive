<?php

session_start();

function loggedIn() {
  return $_SESSION["loggedIn"] == true;
}

function handleForm() {
  handleLogin();
  handleLogout();
  handleDbg();
}

function handleLogin() {
  $action = filter_input(INPUT_POST, "action", FILTER_DEFAULT); 
  if($action !== "login") return;
  $rcon = file_get_contents("/rcon.pw"); 
  if(strlen($rcon) === 0) {
    echo "Contact an admin. Something is wrong..";
    return;
  }
  $rcon_provided = filter_input(INPUT_POST, "rcon", FILTER_DEFAULT); 
  if(check_password($rcon, $rcon_provided)) {
    $_SESSION["loggedIn"] = true;
  }
}

function handleLogout() {
  $action = filter_input(INPUT_POST, "action", FILTER_DEFAULT); 
  if($action !== "logout") return;
  unset($_SESSION["loggedIn"]);
}

function handleDbg() {
  $action = filter_input(INPUT_POST, "action", FILTER_DEFAULT); 
  if($action !== "dbg") return;
  phpinfo();
}

function displayAdminSection() {
  echo file_get_contents("/flag.txt");
}

function check_password($pw, $hp) {
  if(strlen($pw) != strlen($hp)) return false;
  for($i = 0; $i < strlen($pw); $i++) {
    if(!check_char($pw[$i], $hp[$i]))
      return false;
  }
  return true;
}

function check_char($a, $b) {
  return $a == $b;
}

