<?php

include __DIR__ . "/functions.php";

handleForm();

$isAdmin = loggedIn();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>FrostFire Profiles</title>
  <style>
    body {
      margin: 0;
      font-family: 'Segoe UI', sans-serif;
      background: url('/assets/img/bg.jpg') no-repeat center center fixed;
      background-size: cover;
      color: #fff;
    }

    header {
      background: rgba(0, 0, 0, 0.4);
      padding: 20px;
      text-align: center;
      font-size: 2em;
      font-weight: bold;
      text-shadow: 0 0 10px #000;
    }

    .avatar-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(120px, 1fr));
      gap: 20px;
      padding: 40px;
      background: rgba(255, 255, 255, 0.1);
      backdrop-filter: blur(5px);
    }

    .avatar {
      border-radius: 50%;
      border: 3px solid #fff;
      overflow: hidden;
      width: 100px;
      height: 100px;
      margin: auto;
      box-shadow: 0 0 10px #000;
      transition: transform 0.2s ease;
    }

    .avatar:hover {
      transform: scale(1.1);
    }

    footer {
      padding: 20px;
      background: rgba(0, 0, 0, 0.5);
      text-align: center;
      font-size: 0.9em;
      position: relative;
      color: #ccc;
    }

    .admin-login {
      opacity: 0.2;
      transition: opacity 0.3s ease;
      margin-top: 10px;
    }

    .admin-login:hover {
      opacity: 1;
    }

    .admin-login input[type="password"],
    .admin-login input[type="submit"] {
      padding: 5px;
      border-radius: 5px;
      border: none;
      margin: 5px;
    }

    .admin-section {
      padding: 20px;
      background: rgba(0, 0, 0, 0.6);
      color: #0ff;
      margin: 20px auto;
      max-width: 600px;
      border-radius: 10px;
      box-shadow: 0 0 10px #000;
    }

    .logout-form {
      margin-top: 10px;
    }
  </style>
</head>
<body>

  <header>
    🔥 Hottest Profiles in the Coldest Place ❄️
  </header>

  <section class="avatar-grid">
    <?php
    // Example avatar rendering - replace with real data
    for ($i = 1; $i <= 12; $i++) {
      echo "<div><img src='/assets/avatars/icy_avatar_$i.png' class='avatar' alt='User $i' /></div>";
    }
    ?>
  </section>

  <?php if ($isAdmin): ?>
    <div class="admin-section">
      <h3>🛠 Admin Panel</h3>
      <?php displayAdminSection(); ?>
      <form method="POST" class="logout-form">
        <input type="hidden" name="action" value="logout" />
        <input type="submit" value="Logout" />
      </form>
    </div>
  <?php endif; ?>

  <footer>
    © <?= date("Y") ?> FrostFire Profiles
    <div class="admin-login">
      <form method="POST">
        <input type="hidden" name="action" value="login" />
        <input type="password" name="rcon" placeholder="Enter code..." />
        <input type="submit" value="Go" />
      </form>
    </div>
  </footer>

</body>
</html>
