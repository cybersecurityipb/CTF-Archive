#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cstdint>
#include <cmath>
#include <unistd.h>
#include <sys/mman.h>
#include <linux/filter.h>
#include <linux/seccomp.h>
#include <linux/audit.h>
#include <sys/prctl.h>
#include <sys/syscall.h>
#include <cstddef>

#ifndef SECCOMP_RET_KILL_PROCESS
#define SECCOMP_RET_KILL_PROCESS SECCOMP_RET_KILL
#endif

static int load_seccomp() {
    if (prctl(PR_SET_NO_NEW_PRIVS, 1, 0, 0, 0)) return -1;

    struct sock_filter filter[] = {
        BPF_STMT(BPF_LD  | BPF_W | BPF_ABS, offsetof(struct seccomp_data, arch)),
        BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, AUDIT_ARCH_X86_64, 1, 0),
        BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_KILL_PROCESS),

        BPF_STMT(BPF_LD  | BPF_W | BPF_ABS, offsetof(struct seccomp_data, nr)),

        BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, __NR_execve,     0, 1),
        BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_KILL_PROCESS),
        BPF_JUMP(BPF_JMP | BPF_JEQ | BPF_K, __NR_execveat,   0, 1),
        BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_KILL_PROCESS),
        BPF_STMT(BPF_RET | BPF_K, SECCOMP_RET_ALLOW),
    };

    struct sock_fprog prog = {
        .len    = (unsigned short)(sizeof(filter)/sizeof(filter[0])),
        .filter = filter
    };
    return prctl(PR_SET_SECCOMP, SECCOMP_MODE_FILTER, &prog);
}

static const int MAX_SLOTS = 10;

static inline void* TAG_INT()   { return (void*)(uintptr_t)0x11111111ull; }
static inline void* TAG_FLOAT() { return (void*)(uintptr_t)0x22222222ull; }

enum ObjType : int {
    T_NONE = 0,
    T_JSARRAY = 1,
    T_FIXED_DOUBLE_ARRAY = 2
};

struct JSArrayHeader {
    void*  map;
    void*  properties;
    void*  elements;
    size_t length;
};

struct FixedDoubleArrayHeader {
    void*  map;
    size_t length;
    void*  flt_arr_map;
};

static void*   chunks[MAX_SLOTS];
static ObjType types[MAX_SLOTS];
static int     next_index = 0;

static int* get_edits_ptr() {
    static int* const ptr = (int*)mmap(nullptr, 0x1000, PROT_READ | PROT_WRITE, 
                                        MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    return ptr;
}

static int* get_last_edit_ptr() {
    static int* const ptr = (int*)mmap(nullptr, 0x1000, PROT_READ | PROT_WRITE, 
                                        MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    return ptr;
}

static void init_edits_done() {
    *get_edits_ptr() = 0;
    mprotect(get_edits_ptr(), 0x1000, PROT_READ);
    *get_last_edit_ptr() = 0;
    mprotect(get_last_edit_ptr(), 0x1000, PROT_READ);
}

static int get_edits_done() {
    return *get_edits_ptr();
}

static int get_last_edit() {
    return *get_last_edit_ptr();
}

static void check_edit_integrity() {
    if (get_edits_done() != get_last_edit()) {
        _exit(0);
    }
}

static void increment_edits_done() {
    int* ptr = get_edits_ptr();
    mprotect(ptr, 0x1000, PROT_READ | PROT_WRITE);
    (*ptr)++;
    mprotect(ptr, 0x1000, PROT_READ);
    
    int* last_ptr = get_last_edit_ptr();
    mprotect(last_ptr, 0x1000, PROT_READ | PROT_WRITE);
    (*last_ptr)++;
    mprotect(last_ptr, 0x1000, PROT_READ);
}

#define edits_done (get_edits_done())

static long read_long() {
    char buf[128];
    if (!fgets(buf, sizeof(buf), stdin)) return -1;
    return strtol(buf, nullptr, 10);
}
static double read_double() {
    char buf[256];
    if (!fgets(buf, sizeof(buf), stdin)) return 0.0;
    return strtod(buf, nullptr);
}

static bool parse_len_and_is_float(const char* line, double& out_val, bool& is_float_syntax) {
    while (*line==' '||*line=='\t') ++line;
    char tok[128]; size_t k=0;
    while (*line && k+1<sizeof(tok)) {
        char c=*line;
        if ((c>='0'&&c<='9')||c=='+'||c=='-'||c=='.'||c=='e'||c=='E'){ tok[k++]=c; ++line; }
        else break;
    }
    tok[k]='\0';
    if (k==0) return false;
    is_float_syntax = (strchr(tok,'.')!=nullptr) || (strchr(tok,'e')!=nullptr) || (strchr(tok,'E')!=nullptr);
    out_val = strtod(tok,nullptr);
    return true;
}

static void v8_prompt() {
    printf("d8> ");
    fflush(stdout);
}
static void ensure_map_is_malloc_addr(int idx) {
    if (!chunks[idx]) _exit(0);
    if (types[idx] == T_JSARRAY) {
        auto* h = (JSArrayHeader*)chunks[idx];
        if (h->map != chunks[idx]) _exit(0);
    } else if (types[idx] == T_FIXED_DOUBLE_ARRAY) {
        auto* h = (FixedDoubleArrayHeader*)chunks[idx];
        if (h->map != chunks[idx]) _exit(0);
    } else {
        _exit(0);
    }
}
static int next_free_slot() {
    for (int i = 0; i < MAX_SLOTS; i++) {
        int idx = (next_index + i) % MAX_SLOTS;
        if (!chunks[idx]) return idx;
    }
    return -1;
}

#define MAX_ARRAY_LENGTH 16

static void preview_and_length_int(int idx, const int* data, size_t n) {
    printf("d8> arr%d = [", idx);
    size_t show = n < 8 ? n : 8;
    for (size_t i = 0; i < show; i++) {
        if (i) fputs(", ", stdout);
        printf("%d", data[i]);
    }
    if (n > show) fputs(", ...", stdout);
    puts("];");
    printf("d8> arr%d.length\n%zu\n", idx, n);
}
static void preview_and_length_double(int idx, const double* data, size_t n) {
    printf("d8> arr%d = [", idx);
    size_t show = n < 8 ? n : 8;
    for (size_t i = 0; i < show; i++) {
        if (i) fputs(", ", stdout);
        printf("%g", data[i]);
    }
    if (n > show) fputs(", ...", stdout);
    puts("];");
    printf("d8> arr%d.length\n%zu\n", idx, n);
}
static void preview_and_length_float(int idx, const float* data, size_t n) {
    printf("d8> arr%d = [", idx);
    size_t show = n < 8 ? n : 8;
    for (size_t i = 0; i < show; i++) {
        if (i) fputs(", ", stdout);
        printf("%g", (double)data[i]);
    }
    if (n > show) fputs(", ...", stdout);
    puts("];\n");
    printf("d8> arr%d.length\n%zu\n", idx, n);
}

static void create_jsarray(int idx) {
    printf("d8> let len = ");
    char line[256];
    if (!fgets(line, sizeof(line), stdin)) { puts("\nBad length."); return; }

    double len_in = 0.0; bool is_float = false;
    if (!parse_len_and_is_float(line, len_in, is_float)) { puts("Bad length."); return; }
    long n_floor = (long)std::floor(len_in);
    if (n_floor <= 0 || n_floor > MAX_ARRAY_LENGTH) { puts("Bad length."); return; }

    uint64_t bits;
    memcpy(&bits, &len_in, sizeof(double));
    size_t n = (size_t)n_floor;

    size_t elem_sz = is_float ? sizeof(float) : sizeof(int);
    size_t total   = sizeof(JSArrayHeader) + n * elem_sz;

    void* mem = calloc(1, total);
    if (!mem) { puts("alloc failed"); _exit(1); }

    auto* h = (JSArrayHeader*)mem;
    h->map        = mem;
    h->properties = is_float ? TAG_FLOAT() : TAG_INT();
    h->elements   = (char*)mem + sizeof(JSArrayHeader);
    h->length     = is_float ? bits : n;

    printf("d8> var arr%d = new Array(len)\n", idx);

    if (is_float) {
        float* data = (float*)h->elements;
        for (size_t i = 0; i < n; i++) {
            printf("d8> arr%d[%zu] = ", idx, i);
            data[i] = (float)read_double();
            printf("%g\n", (double)data[i]);
        }
        preview_and_length_float(idx, data, n);
    } else {
        int* data = (int*)h->elements;
        for (size_t i = 0; i < n; i++) {
            printf("d8> arr%d[%zu] = ", idx, i);
            data[i] = (int)read_double();
            printf("%d\n", data[i]);
        }
        preview_and_length_int(idx, data, n);
    }

    chunks[idx] = mem;
    types[idx]  = T_JSARRAY;
    next_index = (idx + 1) % MAX_SLOTS;
}

static void create_fda(int idx) {
    printf("d8> let len = ");
    long n_in = read_long();

    if (n_in <= 0 || n_in > MAX_ARRAY_LENGTH) { puts("Bad length."); return; }
    size_t n = (size_t)n_in;

    size_t total = sizeof(FixedDoubleArrayHeader) + n * sizeof(double);

    void* mem = calloc(1, total);
    if (!mem) { puts("alloc failed"); _exit(1); }

    auto* h = (FixedDoubleArrayHeader*)mem;
    h->map         = mem;
    h->length      = n;
    h->flt_arr_map = (void*)0x44444444;

    double* data = (double*)((char*)mem + sizeof(FixedDoubleArrayHeader));

    printf("d8> var arr%d = new Array(%zu)\n", idx, n);
    for (size_t i = 0; i < n; i++) {
        printf("d8> arr%d[%zu] = ", idx, i);
        data[i] = read_double();
        printf("%g\n", data[i]);
    }

    preview_and_length_double(idx, data, n);

    chunks[idx] = mem;
    types[idx]  = T_FIXED_DOUBLE_ARRAY;
    next_index = (idx + 1) % MAX_SLOTS;
}

static void v8_create() {
    check_edit_integrity();
    int idx = next_free_slot();
    if (idx < 0) { puts("No free slot."); return; }
    puts("Type?");
    puts("1) JSArray");
    puts("2) FixedDoubleArray");
    printf("> ");
    long t = read_long();
    if (t == 1)      create_jsarray(idx);
    else if (t == 2) create_fda(idx);
    else puts("Unknown type.");
}

static void print_jsarray_debug(long idx, JSArrayHeader* h) {
    printf("d8> %%DebugPrint(arr%ld);\n", idx);
    puts("DebugPrint: [JSArray]");
    printf(" - prototype: <JSArray[%zu]>\n", (size_t)idx);
    printf(" - length: %zu\n", h->length);
    printf(" - properties: %p\n", h->properties);
    puts(" - elements: {");
    if (h->properties == TAG_FLOAT()) {
        float* data = (float*)h->elements;
        for (size_t i = 0; i < h->length; ++i) {
            printf("           %zu: %g\n", i, (double)data[i]);
        }
    } else {
        int* data = (int*)h->elements;
        for (size_t i = 0; i < h->length; ++i) {
            printf("           %zu: %d\n", i, data[i]);
        }
    }
    puts(" }");
}

static void print_fda_debug(long idx, FixedDoubleArrayHeader* h) {
    printf("d8> %%DebugPrint(arr%ld);\n", idx);
    puts("DebugPrint: [FixedDoubleArray]");
    printf(" - prototype: <FixedDoubleArray>\n");
    printf(" - length: %zu\n", h->length);
    printf(" - properties: %p\n", h->flt_arr_map);

    puts(" - elements: {");
    double* data = (double*)((char*)h + sizeof(FixedDoubleArrayHeader));
    for (size_t i = 0; i < h->length; ++i) {
        printf("           %zu: %g\n", i, data[i]);
    }
    puts(" }");
}

static void v8_read() {
    check_edit_integrity();
    puts("Index?");
    printf("> ");
    long idx = read_long();
    if (idx < 0 || idx >= MAX_SLOTS || !chunks[idx]) { puts("Empty/bad slot."); return; }

    ensure_map_is_malloc_addr((int)idx);

    if (types[idx] == T_JSARRAY) {
        print_jsarray_debug(idx, (JSArrayHeader*)chunks[idx]);
    } else if (types[idx] == T_FIXED_DOUBLE_ARRAY) {
        print_fda_debug(idx, (FixedDoubleArrayHeader*)chunks[idx]);
    } else {
        puts("Unknown type.");
    }
}

static void v8_edit() {
    check_edit_integrity();
    if (edits_done >= 4) { puts("edit quota exceedeed"); return; }

    puts("Slot?");
    printf("> ");
    long idx = read_long();
    if (idx < 0 || idx >= MAX_SLOTS || !chunks[idx]) { puts("Empty/bad slot."); return; }

    ensure_map_is_malloc_addr((int)idx);

    puts("Element index?");
    printf("> ");
    long eidx = read_long();

    if (types[idx] == T_JSARRAY) {
        auto* h = (JSArrayHeader*)chunks[idx];
        if (eidx < 0 || (size_t)eidx >= h->length) { puts("OOB (int)"); return; }
        if (h->properties == TAG_INT()) {
            int* data = (int*)h->elements;
            printf("d8> arr%ld[%ld] = ", idx, eidx);
            double val = read_double();
            data[eidx] = (int)val;
            increment_edits_done();
            printf("%d\n", data[eidx]);
        } else if (h->properties == TAG_FLOAT()) {
            double* data_as_double = (double*)h->elements;
            printf("d8> arr%ld[%ld] = ", idx, eidx);
            double val = read_double();
            data_as_double[eidx] = val;
            increment_edits_done();
            printf("%.17g\n", val);
        } else {
            puts("Bad properties tag.");
        }

    } else if (types[idx] == T_FIXED_DOUBLE_ARRAY) {

        auto* h = (FixedDoubleArrayHeader*)chunks[idx];
        if (eidx < 0 || (size_t)eidx >= h->length) { puts("OOB (fda)"); return; }
        double* data = (double*)((char*)h + sizeof(FixedDoubleArrayHeader));
        printf("d8> arr%ld[%ld] = ", idx, eidx);
        double val = read_double();
        data[eidx] = val;
        increment_edits_done();
        printf("%.17g\n", val);
    } else {
        puts("Unknown type.");
    }
}

static void v8_free() {
    check_edit_integrity();
    puts("Slot?");
    printf("> ");
    long idx = read_long();
    if (idx < 0 || idx >= MAX_SLOTS || !chunks[idx]) { puts("Empty/bad slot."); return; }
    printf("d8> arr%ld = null\n", idx);
    free(chunks[idx]);
    chunks[idx] = nullptr;
    puts("null");
}

static void trim_newline(char* s) {
    size_t n = strlen(s);
    while (n > 0 && (s[n-1] == '\n' || s[n-1] == '\r')) s[--n] = 0;
}
static void trim_spaces(char* s) {
    size_t n = strlen(s);
    size_t i = 0; while (i < n && (s[i] == ' ' || s[i] == '\t')) ++i;
    size_t j = n; while (j > i && (s[j-1] == ' ' || s[j-1] == '\t')) --j;
    if (i > 0) memmove(s, s + i, j - i);
    s[j - i] = 0;
}
static void sanitize_cmd(char* s) {
    size_t j = 0; for (size_t i = 0; s[i]; ++i) {
        unsigned char c = (unsigned char)s[i];
        if (c==' '||c=='\t'||c=='\r'||c=='\n') continue;
        if (c==';') continue;
        if (c>='A' && c<='Z') c = (unsigned char)(c - 'A' + 'a');
        s[j++] = (char)c;
    }
    s[j] = 0;
}
static bool is_cmd(const char* s, const char* a) { return strcmp(s,a)==0; }
static void extract_symbol(const char* s, char* out, size_t outsz) {
    const char* p = s;
    while (*p && (*p==' '||*p=='\t')) ++p;
    if (!*p) { out[0] = 0; return; }
    const char* start = p;
    if (((*p>='A'&&*p<='Z')||(*p>='a'&&*p<='z')||*p=='_'||*p=='$')) {
        ++p;
        while (*p && ((*p>='A'&&*p<='Z')||(*p>='a'&&*p<='z')||(*p>='0'&&*p<='9')||*p=='_'||*p=='$')) ++p;
    } else {
        while (*p && *p!=' ' && *p!='\t' && *p!='(') ++p;
    }
    size_t len = (size_t)(p - start);
    if (len >= outsz) len = outsz - 1;
    memcpy(out, start, len);
    out[len] = 0;
}
static void v8_print_ref_error(const char* raw) {
    char tmp[512]; strncpy(tmp, raw ? raw : "", sizeof(tmp) - 1); tmp[sizeof(tmp) - 1] = 0;
    trim_newline(tmp);
    trim_spaces(tmp);
    if (tmp[0] == '\0') return;
    char sym[128]; extract_symbol(tmp, sym, sizeof(sym));
    if (sym[0] == '\0') { strncpy(sym, tmp, sizeof(sym) - 1); sym[sizeof(sym) - 1] = 0; }
    printf("(d8):1: ReferenceError: %s is not defined\n", sym);
    puts(tmp);
    puts("^");
    printf("ReferenceError: %s is not defined\n", sym);
    puts("    at (d8):1:1");
}

static bool matches_command(const char* s, const char* base) {
    char a[64], b[64], c[64], d[64];
    snprintf(a, sizeof(a), "%s()", base);
    snprintf(b, sizeof(b), "%s();", base);
    snprintf(c, sizeof(c), "v8_%s()", base);
    snprintf(d, sizeof(d), "v8_%s();", base);
    return is_cmd(s,a) || is_cmd(s,b) || is_cmd(s,c) || is_cmd(s,d);
}

static void v8_menu() {
    puts("Available commands:");
    puts("  create() / v8_create()  - Create a new JSArray or FixedDoubleArray");
    puts("  read()   / v8_read()    - Read/display an array");
    puts("  edit()   / v8_edit()    - Edit an array element (max 3 edits)");
    puts("  free()   / v8_free()    - Delete/free an array");
    puts("  help()   / ?            - Show this menu");
    puts("  version()               - Show V8 version");
    puts("  exit()   / quit()       - Exit the program");
}

int main() {
    setvbuf(stdin,  nullptr, _IONBF, 0);
    setvbuf(stdout, nullptr, _IONBF, 0);
    setvbuf(stderr, nullptr, _IONBF, 0);

    load_seccomp();

    memset(chunks, 0, sizeof(chunks));
    memset(types,  0, sizeof(types));

    init_edits_done();

    puts("V8 version 13.1.0 (candidate)");

    char line_raw[512];
    char line[512];
    char display[512];
    while (true) {
        v8_prompt();
        if (!fgets(line_raw, sizeof(line_raw), stdin)) break;
        strncpy(display, line_raw, sizeof(display) - 1);
        display[sizeof(display) - 1] = 0;
        trim_newline(display);
        trim_spaces(display);
        strncpy(line, line_raw, sizeof(line) - 1);
        line[sizeof(line) - 1] = 0;
        sanitize_cmd(line);
        if (line[0] == '\0') continue;
        if (matches_command(line, "create")) { v8_create(); continue; }
        if (matches_command(line, "read"))   { v8_read();   continue; }
        if (matches_command(line, "edit"))   { v8_edit();   continue; }
        if (matches_command(line, "free"))   { v8_free();   continue; }
        if (matches_command(line, "help") || is_cmd(line, "?")) { v8_menu(); continue; }
        if (matches_command(line, "version")) { puts("V8 version 13.1.0 (candidate)"); continue; }
        if (matches_command(line, "exit") || matches_command(line, "quit") || is_cmd(line, ".exit")) { _exit(0); }
        v8_print_ref_error(display);
    }
    return 0;
}
